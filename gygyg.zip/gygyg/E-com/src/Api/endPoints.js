export const baseURL = 'https://fakestoreapi.com'

export const endPoint = {
  produts: '/products',
  
}

