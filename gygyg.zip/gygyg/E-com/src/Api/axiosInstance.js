import axios from 'axios'
import { baseURL } from './endPoints'

export const axiosInstance = axios.create({
  baseURL: baseURL,
  // timeout:10
})

// axiosInstance.defaults.headers.common['Authorization'] = 'AUTH_TOKEN'

//Handle request
axiosInstance.interceptors.request.use((config) => {
  // console.log('config', config)
  return config
})

//Handle response
axiosInstance.interceptors.response.use(
  (res) => {
    // console.log('response', res)
    return res
  },
  (error) => {
    alert('API error')
    console.log('response', res)
  }
)
