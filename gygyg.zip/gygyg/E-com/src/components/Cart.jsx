import React from 'react'
import './cart.css'
import { useSelector, useDispatch } from 'react-redux'
import { decreseItem, increaseItem, removeProduct } from '../redux/cartSlice'

const Cart = () => {
  const { cartData } = useSelector((state) => {
    return state.cart
  })
  console.log(cartData)
  const dispatch = useDispatch()
  const removeItem = (id) => dispatch(removeProduct(id))
  const increaseQty = (id) => dispatch(increaseItem(id))
  const decreaseQty = (id) => dispatch(decreseItem(id))
  
  const totalAmount = cartData
    .map((items) => items.price * items.qty)
    .reduce((a, c) => a + c, 0)
    .toFixed(2)

  const totalItems = cartData
    .map((items) => items.qty)
    .reduce((a, c) => a + c, 0)
  return (
    <>
      <div className='card'>
        <div className='row'>
          <div className='col-md-8 cart'>
            <div className='title'>
              <div className='row'>
                <div className='col'>
                  <h4>
                    <b>Shopping Cart</b>
                  </h4>
                </div>
                <div className='col align-self-center text-right text-muted'>
                  ITEMS:{totalItems}
                </div>
              </div>
            </div>
            {cartData.map((items, index) => {
              console.log(items)
              const { id, title, image, price, qty } = items
              console.log(price)
              return (
                <div className='row border-top border-bottom' key={id}>
                  <div className='row main align-items-center'>
                    <div className='col-2'>
                      <img className='img-fluid' src={image} />
                    </div>
                    <div className='col'>
                      <div className='row text-muted'>Product Details</div>
                      <div className='row'>{title}</div>
                      {/* <div className='row'>{description}</div> */}
                    </div>
                    <div className='col'>
                      <button onClick={() => decreaseQty(id)}>-</button>
                      <button className='border'>{qty}</button>
                      <button onClick={() => increaseQty(id)}>+</button>
                    </div>
                    <div className='col'>
                      Rs {price * qty}
                      <button className='close' onClick={() => removeItem(id)}>
                        &#10005;
                      </button>
                    </div>
                  </div>
                </div>
              )
            })}

            <div className='back-to-shop'>
              <a href='#'>&leftarrow;</a>
              <span className='text-muted'>Back to shop</span>
            </div>
          </div>
          <div className='col-md-4 summary'>
            <div>
              <h5>
                <b>Summary</b>
              </h5>
            </div>
            <hr />

            <form>
              <p>SHIPPING</p>
              <select>
                <option className='text-muted'>
                  Standard-Delivery- &euro;5.00
                </option>
              </select>
              <p>GIVE CODE</p>
              <input id='code' placeholder='Enter your code' />
            </form>
            <div
              className='row'
              style={{
                'border-top': '1px solid rgba(0,0,0,.1)',
                padding: '2vh 0',
              }}
            >
              <div className='col'>TOTAL PRICE</div>
              <div className='col text-right'>Rs.{totalAmount}</div>
            </div>
            <button className='btn'>CHECKOUT</button>
          </div>
        </div>
      </div>
    </>
  )
}

export default Cart
