import React, { useEffect, useState } from "react";
import { axiosInstance } from "../Api/axiosInstance";
import { endPoint } from "../Api/endPoints";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { addProduct } from "../redux/cartSlice";
import { Link } from "react-router-dom";
import "./Home.css";

const Home = () => {
  const { searchTerm } = useSelector((state) => state.cart);
  const [products, setProducts] = useState([]);
  const [filterProduct, setFilterProduct] = useState([]);

  const [pagination, setPagination] = useState({
    currentPage: 1,
    itemsPerPage: 5, 
  });
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const getProducts = async () => {
    try {
      const { data } = await axiosInstance.get(`${endPoint.produts}`);
      return data;
    } catch (error) {
      console.error("Error fetching products:", error);
      return [];
    }
  };

  useEffect(() => {
    getProducts().then((data) => {
      setProducts(data); // Viewing all data
      setFilterProduct(data); //Showing Data on Current page
    });
  }, []);

  // Function to handle pagination logic
  // const filteredProducts = products.filter((element) =>
  //   element.title.toLowerCase().includes(searchTerm.toLowerCase())
  // );

  const handlePageChange = (pageNumber) => {
    setPagination({ ...pagination, currentPage: pageNumber });
  };

  const filterItems = (category) => {
    const updatedItems = products.filter((item) => item.category === category);
    setFilterProduct(updatedItems);
  };

  const { currentPage, itemsPerPage } = pagination;
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const displayedProducts = filterProduct.slice(startIndex, endIndex);

  const totalPages = Math.ceil(filterProduct.length / itemsPerPage);

  return (
    <div className="m-4 ">
      {/* Your radio buttons for filtering */}
      <input
        className="form-check-input"
        type="radio"
        name="flexRadioDefault"
        id="flexRadioDefault1"
        onChange={() => filterItems("men's clothing")}
      />
      <label className="form-check-label" htmlFor="flexRadioDefault1">
        Men's clothing
      </label>

      <input
        className="form-check-input"
        type="radio"
        name="flexRadioDefault"
        id="flexRadioDefault1"
        onChange={() => filterItems("women's clothing")}
      />
      <label className="form-check-label" htmlFor="flexRadioDefault1">
        Women's clothing
      </label>

      <input
        className="form-check-input"
        type="radio"
        name="flexRadioDefault"
        id="flexRadioDefault1"
        onChange={() => filterItems("jewelery")}
      />
      <label className="form-check-label" htmlFor="flexRadioDefault1">
        Jewelery
      </label>

      <input
        className="form-check-input"
        type="radio"
        name="flexRadioDefault"
        id="flexRadioDefault2"
        onChange={() => filterItems("electronics")}
      />
      <label className="form-check-label" htmlFor="flexRadioDefault2">
        Electronics
      </label>
      {/* Product display */}
      <div className="m-5 d-flex justify-content-between flex-wrap">
        {displayedProducts
          .filter((element) =>
            element.title.toLowerCase().includes(searchTerm.toLowerCase())
          )
          .map((item) => (
            <div className="m-3 card" style={{ width: "18rem" }} key={item.id}>
              <img
                src={item.image}
                className="card-img-top"
                alt="..."
                style={{ height: "200px" }}
              />
              <div className="card-body">
                <h5 className="card-title">
                  <b>{item.title.substring(0, 15)}</b>
                </h5>
                <p className="card-price">$ {item.price}</p>

                <button
                  className="btnnn btn-outline-success"
                  onClick={() => {
                    dispatch(addProduct(item));
                    navigate("/cart");
                  }}
                >
                  Add To Cart
                </button>
                <Link
                  className="btnn btn-outline-success"
                  to={`/productDetails/${item.id}`}
                >
                  View Details
                </Link>
              </div>
            </div>
          ))}
      </div>

      {/* Pagination */}
      <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center">
          {Array.from({ length: totalPages }, (_, i) => (
            <li
              key={i + 1}
              className={`page-item ${currentPage === i + 1 ? 'active' : ''}`}
            >
              <a
                className="page-link"
                href="#"
                onClick={() => handlePageChange(i + 1)}
              >
                {i + 1}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
};

export default Home;
