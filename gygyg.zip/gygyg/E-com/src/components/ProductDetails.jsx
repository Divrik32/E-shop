import React, { useEffect, useState }  from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { axiosInstance } from '../Api/axiosInstance'
import {endPoint}  from '../Api/endPoints'
import { addProduct } from "../redux/cartSlice";
import { useDispatch } from 'react-redux'


const ProductDetails = () => {
  const [data, setData] = useState(null)
  console.log(data)
  const { id } = useParams()
  console.log(id)
  const getProductDetails = async () => {
    const productDetails = await axiosInstance.get(`${endPoint.produts}/${id}`)
    return productDetails?.data
  }
  const dispatch = useDispatch();
  const navigate =useNavigate()

  useEffect(() => {
    getProductDetails().then((res) => setData(res))
  }, [id])
  return (
    <div className='container mt-5 mb-5'>
      <div className='row d-flex justify-content-center'>
        <div className='col-md-10'>
          <div className='card'>
            <div className='row'>
              <div className='col-md-6'>
                <div className='images p-3'>
                  <div className='text-center p-4'>
                    <img
                      id='main-image'
                      src={data?.image}
                      style={{ height: '400px', width: '300px' }}
                    />
                  </div>
                </div>
              </div>
              <div className='col-md-6'>
                <div className='product p-4'>
                  <div className='d-flex justify-content-between align-items-center'>
                    <i className='fa fa-shopping-cart text-muted'></i>
                  </div>
                  <div className='mt-4 mb-3'>
                    <span className='text-uppercase text-muted brand'>
                      {data?.category}
                    </span>
                    <h5 className='text-uppercase'>{data?.title}</h5>
                    <div className='price d-flex flex-row align-items-center'>
                      {' '}
                      <h4 className='act-price'>${data?.price}</h4>
                    </div>
                  </div>
                  <p className='about'>{data?.description}</p>
                  <div className='cart mt-4 align-items-center'>
                    <button className='btn btn-danger text-uppercase mr-2 px-4'
                                                          onClick={() => {
                                                            dispatch(addProduct(data));
                                                            navigate("/cart");
                                                          }}>
                      Add to cart
                    </button>
                  
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ProductDetails