import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Home from './components/Home'
import Navbar from './components/Layouts/Navbar'
import Cart from './components/Cart'
import ProductDetails from './components/ProductDetails'
 import './App.css'

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/cart' element={<Cart />} />
        <Route path='/productDetails/:id' element={<ProductDetails/>} />
      </Routes>
    </Router>
  )
}

export default App
