import { createSlice } from '@reduxjs/toolkit'

const cartSlice = createSlice({
  name: 'cart',
  initialState: {
     cartData: [], 
     searchTerm: '' 
    },
  reducers: {
    //add item
    addProduct(state, action) {
      const numId = Number(action.payload.id)
      const existingProduct = state.cartData.find(
        (item) => Number(item.id) === numId
      )

      if (existingProduct) {
        return {
          ...state,
          cartData: state.cartData.map((item) =>
            Number(item.id) === numId ? { ...item, qty: item.qty + 1 } : item
          ),
        }
      }

      return {
        ...state,
        cartData: [...state.cartData, { ...action.payload, qty: 1 }],
      }
    },
    //remove item
    removeProduct(state, action) {
      return {
        ...state,
        cartData: state.cartData.filter((item) => item.id !== action.payload),
      }
    },
    //increase qty
    increaseItem(state, action) {
      state.cartData = state.cartData.filter((item) => {
        return item.id === action.payload ? (item.qty += 1) : item
      })
    },
    //decrease qty
    decreseItem(state, action) {
      state.cartData = state.cartData.filter((item) => {
        return item.id === action.payload ? (item.qty -= 1) : item
      })
    },
    //searchQuery
    searchItem(state, action) {
      return {
        ...state,
        searchTerm: action.payload,
      }
    },
  },
})

export const {
  addProduct,
  removeProduct,
  increaseItem,
  decreseItem,
  searchItem,
} = cartSlice.actions
export const cartReducer = cartSlice.reducer
